module.exports = {
  babelrcRoots: ['.', 'packages/*'],
  presets: ['babel-preset-gatsby'],
};
